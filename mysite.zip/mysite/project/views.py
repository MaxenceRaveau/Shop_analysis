
#Importation of libraries
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from django.shortcuts import render
from django.http import HttpResponse
import matplotlib.pyplot as plt
import matplotlib
from io import BytesIO
import base64
from sklearn.model_selection import GridSearchCV
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from django import forms
import traceback
from sklearn.preprocessing import StandardScaler

class Form(forms.Form):
    penalty_choices = [
        ("l1","l1"),
        ("l2","l2"),
        ("elasticnet","elasticnet"),
        ("none","none")
    ]

    dual_choices = [
        ("True","True"),
        ("False","False")
    ]

    c_choices = [
        ("0.1","0.1"),
        ("0.2", "0.2"),
        ("0.3", "0.3"),
        ("0.4", "0.4"),
        ("0.5", "0.5"),
        ("0.6", "0.6"),
        ("0.7", "0.7"),
        ("0.8", "0.8"),
        ("0.9", "0.9"),
    ]

    fit_choices = [
        ("True", "True"),
        ("False", "False")
    ]

    intercept_scaling_choices = [
        ("0.01","0.01"),
        ("0.05", "0.05"),
        ("0.1", "0.1"),
        ("0.15", "0.15"),
        ("0.2", "0.2"),
        ("0.5", "0.5"),
        ("1", "1"),
        ("1.5", "1.5"),
        ("3", "3"),
        ("5", "5"),
        ("10", "10"),
        ("20", "20"),
    ]

    solver_choices = [
        ("newton-cg","newton-cg"),
        ("lbfgs","lbfgs"),
        ("liblinear","liblinear"),
        ("sag","sag"),
        ("saga","saga")
    ]

    multi_class_choices = [
        ("auto","auto"),
        ("ov","ov"),
        ("multimonial","multimonial")
    ]

    penalty_field = forms.ChoiceField(choices=penalty_choices)
    dual_field = forms.ChoiceField(choices=dual_choices)
    c_field = forms.ChoiceField(choices=c_choices)
    fit_field = forms.ChoiceField(choices=fit_choices)
    intercept_field = forms.ChoiceField(choices=intercept_scaling_choices)
    solver_field = forms.ChoiceField(choices=solver_choices)
    multi_class_field = forms.ChoiceField(choices=multi_class_choices)


#Read csv

df = pd.read_csv("online_shoppers_intention.csv")





def index(request):
    if request.POST:
        #Creating context to load the same page

        context = {
            "df_head": df.head().to_html(),
            "df_groupby_visitor_count": df.groupby("VisitorType").count().to_html,
            "df_shape": df.shape,
            "df_describe": df.describe().to_html,
            "form": Form(),
        }

        #Getting form Data

        form = Form(request.POST)
        penalty = request.POST["penalty_field"]
        dual = request.POST["dual_field"]
        if dual == "True":
            dual = True
        else:
            dual = False
        c = float(request.POST["c_field"])
        fit_intercept = float(request.POST["intercept_field"])
        solver = request.POST["solver_field"]
        multi_class = request.POST["multi_class_field"]

        #Preparing Data for Logistic Regression

        df["Month"].replace(["Feb", "Mar", "May", "June", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                            [2, 3, 5, 6, 7, 8, 9, 10, 11, 12], inplace=True)
        df["Month"].replace(["Aug"],[8], inplace=True)
        df["VisitorType"].replace(["Returning_Visitor", "New_Visitor", "Other"], [0, 1, 2], inplace=True)
        df["Weekend"].replace([True, False], [0, 1], inplace=True)
        df["Revenue"].replace([True, False], [0, 1], inplace=True)
        df.drop("OperatingSystems", axis=1)
        df.drop("Browser", axis=1)
        df.drop("TrafficType", axis=1)
        variables = df.drop("Revenue", axis=1)
        target = df["Revenue"]
        var_train, var_test, tar_train, tar_test = train_test_split(variables, target, test_size=0.4, random_state=22)
        trainIndexes = var_train.index
        testIndexes = var_test.index
        trainColumns = var_train.columns
        testColumns = var_test.columns
        scaler = StandardScaler()

        scaler.fit(var_train)  # We only fit on the trainning data
        var_train = pd.DataFrame(scaler.transform(var_train))
        var_test = pd.DataFrame(scaler.transform(var_test))

        var_train.index = trainIndexes
        var_test.index = testIndexes
        var_train.columns = trainColumns
        var_test.columns = testColumns
        variables = df

        #Starting Logistic Regression

        logisticRegr = LogisticRegression(penalty=penalty,dual=dual,C=c,fit_intercept=fit_intercept,solver=solver,multi_class=multi_class)
        logisticRegr.fit(var_train,tar_train)
        score = logisticRegr.score(var_test,tar_test)
        context["score"] = str(round(score*100,ndigits=2)) +"%"
        return render(request, "project/index.html", context=context)

        #context["error"] = "Invalid Combo of variables, you need to try another one \n"

    else:
        context = {
            "df_head": df.head().to_html(),
            "df_groupby_visitor_count": df.groupby("VisitorType").count().to_html,
            "df_shape": df.shape,
            "df_describe": df.describe().to_html,
            "form":Form(),
        }
        return render(request, "project/index.html", context=context)

